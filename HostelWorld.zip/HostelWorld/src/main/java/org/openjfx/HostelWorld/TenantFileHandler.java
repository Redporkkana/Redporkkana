package org.openjfx.HostelWorld;


/**
 *
 * @author anna
 */
public class TenantFileHandler {
    public static void saveRecords(int numOfRooms, TenantList tenantList){
    
    }
 public static void readRecords(TenantList tenantList){
    
    }            
}
