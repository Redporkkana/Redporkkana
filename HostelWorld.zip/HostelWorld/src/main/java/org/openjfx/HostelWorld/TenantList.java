package org.openjfx.HostelWorld;


import java.util.ArrayList;


/**Collection class to hold a list of tenants
 *
 * @author Anna Matilainen
 */
public class TenantList {
    
    private ArrayList<Tenant> tList; 
    public final int MAX;
/** Constructor initialises the empty tenant list and sets the maximum list size * @param maxIn The maximum number of tenants in the list
*/
    public TenantList(int maxIn) {
        tList = new ArrayList<>();
        MAX = maxIn; 
    }
    public boolean isFull(){
        return tList.size()==MAX;
    }
    public boolean isEmpty(){
        return tList.isEmpty();
    }
/** Adds a new Tenant to the list
* @param tIn The Tenant to add
* @return Returns true if the tenant was added successfully and false otherwise */
    
    public boolean addTenant(Tenant tIn) {
        if(!isFull()) {
            tList.add(tIn); 
            return true;
        }
        else {
            return false; }
        }
    public Tenant search(int roomIn){
        for (Tenant currentTenant:tList){
            if (currentTenant.getRoom()==roomIn){
                return currentTenant;
            }            
        }
        return null;
    }
    
    public boolean removeTenant(int roomIN){
        Tenant findTenant =search(roomIN);
        if (findTenant!=null){
            tList.remove(findTenant);
            return true;
        }
        else return false;
    }
    
    public Tenant getTenant(int positionIN){
        if (positionIN<1 || positionIN > getTotal()){
            return null;
        }
        else return tList.get(positionIN-1);
    }
    
    public int getTotal(){
        return tList.size();
    }
    
    @Override
    public String toString(){
        return tList.toString();
    }
}