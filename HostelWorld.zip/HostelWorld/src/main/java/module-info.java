module com.mycompany.hostelworld {
    requires javafx.controls;
    exports com.mycompany.hostelworld;
}
